# Do Blink IT College: full-stack source

Next.js 14 (App Router) + TypeScript + Prisma + PostgreSQL. Sessions are signed JWT cookies (httpOnly), passwords are hashed with bcrypt, and every admin API route and admin page re-checks the role on the server.

**Status: written but NOT yet run.** It was authored without network access, so dependencies were not installed, nothing was type-checked, built or tested. Expect to fix a few small errors on first run (`npm run typecheck` is the quickest way to find them).

## Setup

Requirements: Node 18.18+ and a PostgreSQL database.

1. `cp .env.example .env` and fill in `DATABASE_URL`, `AUTH_SECRET` (`openssl rand -base64 32`), `ADMIN_EMAIL`, `ADMIN_PASSWORD` (12+ characters).
2. `npm install`
3. `npx prisma migrate dev --name init` (creates the tables and the first migration; commit the generated `prisma/migrations` folder)
4. `npm run db:seed` (creates the admin account and three placeholder courses)
5. `npm run dev` then open http://localhost:3000

Log in at `/login` with the admin email and password to reach `/admin`.

## Production

1. Set the same environment variables on the host (never commit `.env`).
2. `npm ci && npm run build`
3. `npm run db:deploy` (applies migrations), then once: `npm run db:seed`
4. `npm start`. Serve over HTTPS (session cookies are `secure` in production). Vercel, Railway, Render or a VPS all work; use a managed PostgreSQL such as Neon, Supabase or Railway.

## What is implemented (all untested)

- Public: home, courses (search + category filter), course details, admissions, contact, sign up, log in/out.
- Forms: browser validation, server-side Zod validation, per-field error messages, success messages, busy state, duplicate-application protection (unique email + course), basic rate limiting.
- Student dashboard: profile, enrolled courses, applications with status.
- Admin: overview counts from the database, applications (search, filter, approve/reject/pending; approval enrolls a matching student account), students list with search, course create/edit/publish/delete with curriculum modules, contact messages (read/unread/delete).
- Database: users, courses, modules, applications, enrollments, contact messages, testimonials, site content, with relations, indexes and unique constraints.

## Not implemented yet

- Admin screens for website content (the `SiteContent` table exists) and testimonials (the `Testimonial` table exists; the public site does not show testimonials yet).
- Student account settings (change name or password), password reset, email verification, email notifications.
- Course images, WhatsApp link, Google Map (waiting for real details). Sample course data is placeholder only.
- Progress, certificates, attendance and learning materials (deliberately left out until they have backend support).
- Automated tests. The rate limiter is in-memory (use Redis or similar when running several servers). A changed role takes effect when the session cookie expires (7 days).
- Styling uses plain CSS, not Tailwind, and Lucide icons are not used.
