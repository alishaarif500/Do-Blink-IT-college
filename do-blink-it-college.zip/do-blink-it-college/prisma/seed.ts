import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

const courses = [
  { slug: "web-development-basics", title: "Web Development Basics", category: "Web", level: "Beginner", description: "[Placeholder] Build and publish simple websites with HTML, CSS and JavaScript.", outcomes: ["Build responsive pages", "Use core JavaScript", "Publish a small project"], modules: ["How the web works", "HTML structure", "CSS layout", "JavaScript basics", "Final project"] },
  { slug: "python-programming", title: "Python Programming", category: "Programming", level: "Beginner", description: "[Placeholder] Learn programming logic and write useful scripts in Python.", outcomes: ["Write clean Python", "Solve problems with logic", "Work with files and data"], modules: ["Variables and types", "Control flow", "Functions", "Files and data", "Mini project"] },
  { slug: "graphic-design-essentials", title: "Graphic Design Essentials", category: "Design", level: "Beginner", description: "[Placeholder] Learn layout, colour and typography with practical tasks.", outcomes: ["Apply design principles", "Create social and print designs", "Build a portfolio"], modules: ["Design principles", "Colour and type", "Layout", "Brand assets", "Portfolio"] }
];

async function main() {
  const email = process.env.ADMIN_EMAIL?.toLowerCase();
  const pw = process.env.ADMIN_PASSWORD;
  if (!email || !pw || pw.length < 12) throw new Error("Set ADMIN_EMAIL and ADMIN_PASSWORD (12+ characters) in .env");
  await db.user.upsert({
    where: { email }, update: {},
    create: { email, name: "Administrator", role: "ADMIN", passwordHash: await bcrypt.hash(pw, 12) }
  });
  for (const c of courses) {
    const { modules, ...rest } = c;
    await db.course.upsert({
      where: { slug: c.slug }, update: {},
      create: { ...rest, duration: "[To be confirmed]", fee: null, requirements: "[To be confirmed]", published: true,
        modules: { create: modules.map((title, position) => ({ title, position })) } }
    });
  }
  console.log("Seed complete. Sample courses are placeholders: edit them in /admin/courses.");
}
main().finally(() => db.$disconnect());
