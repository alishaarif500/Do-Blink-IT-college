import type { ApplicationStatus } from "@prisma/client";
import { db } from "@/lib/db";
import RowAction from "@/components/RowAction";

export const metadata = { title: "Applications" };
const STATUSES = ["PENDING", "APPROVED", "REJECTED"] as const;

export default async function Applications({ searchParams }: { searchParams: { q?: string; status?: string } }) {
  const q = searchParams.q?.trim();
  const status = STATUSES.find((s) => s === searchParams.status) as ApplicationStatus | undefined;
  const rows = await db.application.findMany({
    where: { status, ...(q ? { OR: [{ fullName: { contains: q, mode: "insensitive" } }, { email: { contains: q, mode: "insensitive" } }] } : {}) },
    orderBy: { createdAt: "desc" }, take: 200, include: { course: { select: { title: true } } }
  });
  return (
    <>
      <h1>Applications</h1>
      <form className="filters" role="search">
        <input name="q" defaultValue={q} placeholder="Search name or email" aria-label="Search" />
        <select name="status" defaultValue={status ?? ""} aria-label="Status"><option value="">All statuses</option>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
        <button className="btn" type="submit">Filter</button>
      </form>
      {rows.length === 0 ? <p className="muted">No applications found.</p> : (
        <div className="tablewrap"><table><thead><tr><th>Applicant</th><th>Course</th><th>Details</th><th>Status</th><th>Actions</th></tr></thead><tbody>
          {rows.map((a) => (
            <tr key={a.id}>
              <td>{a.fullName}<br /><span className="muted">{a.email}<br />{a.phone}</span></td>
              <td>{a.course.title}<br /><span className="muted">{a.createdAt.toLocaleDateString("en-GB")}</span></td>
              <td><details><summary>View</summary><p>Education: {a.education}</p><p>Address: {a.address}</p><p>Message: {a.message || "None"}</p></details></td>
              <td><span className={`badge ${a.status}`}>{a.status}</span></td>
              <td><div className="rowacts">
                {a.status !== "APPROVED" && <RowAction url={`/api/admin/applications/${a.id}`} body={{ status: "APPROVED" }} label="Approve" />}
                {a.status !== "REJECTED" && <RowAction url={`/api/admin/applications/${a.id}`} body={{ status: "REJECTED" }} label="Reject" confirmText="Reject this application?" danger />}
                {a.status !== "PENDING" && <RowAction url={`/api/admin/applications/${a.id}`} body={{ status: "PENDING" }} label="Set pending" />}
              </div></td>
            </tr>))}
        </tbody></table></div>)}
    </>
  );
}
