import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import ApiForm from "@/components/ApiForm";
import { courseFields } from "@/lib/courseFields";

export const metadata = { title: "Edit course" };

export default async function EditCourse({ params }: { params: { id: string } }) {
  const c = await db.course.findUnique({ where: { id: params.id }, include: { modules: { orderBy: { position: "asc" } } } });
  if (!c) notFound();
  const values: Record<string, string | boolean> = {
    title: c.title, category: c.category, level: c.level, duration: c.duration, fee: c.fee == null ? "" : String(c.fee),
    description: c.description, requirements: c.requirements, outcomes: c.outcomes.join("\n"),
    modules: c.modules.map((m) => m.title).join("\n"), published: c.published
  };
  return (
    <>
      <Link href="/admin/courses">&larr; All courses</Link>
      <h1>Edit course</h1>
      <ApiForm url={`/api/admin/courses/${c.id}`} method="PUT" submit="Save changes" success="Course updated." resetOnSuccess={false}
        fields={courseFields.map((f) => ({ ...f, defaultValue: values[f.name] }))} />
    </>
  );
}
