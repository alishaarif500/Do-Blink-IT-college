import Link from "next/link";
import { db } from "@/lib/db";
import ApiForm from "@/components/ApiForm";
import RowAction from "@/components/RowAction";
import { courseFields } from "@/lib/courseFields";

export const metadata = { title: "Manage courses" };

export default async function AdminCourses() {
  const courses = await db.course.findMany({ orderBy: { createdAt: "desc" }, include: { _count: { select: { applications: true } } } });
  return (
    <>
      <h1>Courses</h1>
      {courses.length === 0 ? <p className="muted">No courses yet. Add one below.</p> : (
        <div className="tablewrap"><table><thead><tr><th>Title</th><th>Category</th><th>Fee</th><th>Applications</th><th>Status</th><th>Actions</th></tr></thead><tbody>
          {courses.map((c) => (
            <tr key={c.id}>
              <td>{c.title}</td><td>{c.category}</td><td>{c.fee ?? "Not set"}</td><td>{c._count.applications}</td>
              <td><span className="badge">{c.published ? "Published" : "Draft"}</span></td>
              <td><div className="rowacts">
                <Link className="btn small ghost" href={`/admin/courses/${c.id}`}>Edit</Link>
                <RowAction url={`/api/admin/courses/${c.id}`} body={{ published: !c.published }} label={c.published ? "Unpublish" : "Publish"} />
                <RowAction url={`/api/admin/courses/${c.id}`} method="DELETE" label="Delete" confirmText={`Delete "${c.title}"? This cannot be undone.`} danger />
              </div></td>
            </tr>))}
        </tbody></table></div>)}
      <h2 style={{ marginTop: "2rem" }}>Add a course</h2>
      <ApiForm url="/api/admin/courses" submit="Create course" success="Course created." fields={courseFields} />
    </>
  );
}
