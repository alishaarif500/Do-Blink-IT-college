import Link from "next/link";
import { requirePage } from "@/lib/auth";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requirePage("ADMIN");
  const links: [string, string][] = [["/admin", "Overview"], ["/admin/applications", "Applications"], ["/admin/students", "Students"], ["/admin/courses", "Courses"], ["/admin/messages", "Messages"]];
  return (
    <div className="wrap section">
      <nav className="subnav" aria-label="Admin">{links.map(([h, l]) => <Link key={h} href={h}>{l}</Link>)}</nav>
      {children}
    </div>
  );
}
