import { db } from "@/lib/db";
import RowAction from "@/components/RowAction";

export const metadata = { title: "Messages" };

export default async function Messages() {
  const rows = await db.contactMessage.findMany({ orderBy: { createdAt: "desc" }, take: 200 });
  return (
    <>
      <h1>Contact messages</h1>
      {rows.length === 0 ? <p className="muted">No messages yet.</p> : rows.map((m) => (
        <article className="card" key={m.id} style={{ marginBottom: "1rem" }}>
          <h3>{m.subject} {!m.read && <span className="badge">New</span>}</h3>
          <p className="muted">{m.name} &middot; <a href={`mailto:${m.email}`}>{m.email}</a> &middot; {m.createdAt.toLocaleString("en-GB")}</p>
          <p style={{ whiteSpace: "pre-wrap" }}>{m.message}</p>
          <div className="rowacts">
            <RowAction url={`/api/admin/messages/${m.id}`} body={{ read: !m.read }} label={m.read ? "Mark unread" : "Mark read"} />
            <RowAction url={`/api/admin/messages/${m.id}`} method="DELETE" label="Delete" confirmText="Delete this message?" danger />
          </div>
        </article>))}
    </>
  );
}
