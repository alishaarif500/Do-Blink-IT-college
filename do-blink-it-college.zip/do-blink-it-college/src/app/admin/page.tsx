import { db } from "@/lib/db";

export const metadata = { title: "Admin overview" };

export default async function Overview() {
  const [students, apps, pending, approved, courses, unread, recent] = await Promise.all([
    db.user.count({ where: { role: "STUDENT" } }),
    db.application.count(),
    db.application.count({ where: { status: "PENDING" } }),
    db.application.count({ where: { status: "APPROVED" } }),
    db.course.count({ where: { published: true } }),
    db.contactMessage.count({ where: { read: false } }),
    db.application.findMany({ orderBy: { createdAt: "desc" }, take: 5, include: { course: { select: { title: true } } } })
  ]);
  const stats: [string, number][] = [["Registered students", students], ["Total applications", apps], ["Pending", pending], ["Approved", approved], ["Published courses", courses], ["Unread messages", unread]];
  return (
    <>
      <h1>Overview</h1>
      <div className="grid">{stats.map(([l, n]) => <div className="card" key={l}><p className="muted" style={{ margin: 0 }}>{l}</p><p className="big">{n}</p></div>)}</div>
      <h2 style={{ marginTop: "2rem" }}>Recent applications</h2>
      {recent.length === 0 ? <p className="muted">No applications yet.</p> : (
        <div className="tablewrap"><table><thead><tr><th>Applicant</th><th>Course</th><th>Status</th><th>Date</th></tr></thead><tbody>
          {recent.map((a) => <tr key={a.id}><td>{a.fullName}<br /><span className="muted">{a.email}</span></td><td>{a.course.title}</td><td><span className={`badge ${a.status}`}>{a.status}</span></td><td>{a.createdAt.toLocaleDateString("en-GB")}</td></tr>)}
        </tbody></table></div>)}
    </>
  );
}
