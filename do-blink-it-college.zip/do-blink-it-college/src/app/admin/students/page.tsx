import { db } from "@/lib/db";

export const metadata = { title: "Students" };

export default async function Students({ searchParams }: { searchParams: { q?: string } }) {
  const q = searchParams.q?.trim();
  const rows = await db.user.findMany({
    where: { role: "STUDENT", ...(q ? { OR: [{ name: { contains: q, mode: "insensitive" } }, { email: { contains: q, mode: "insensitive" } }] } : {}) },
    orderBy: { createdAt: "desc" }, take: 200, include: { _count: { select: { enrollments: true } } }
  });
  return (
    <>
      <h1>Students</h1>
      <form className="filters" role="search"><input name="q" defaultValue={q} placeholder="Search name or email" aria-label="Search" /><button className="btn" type="submit">Search</button></form>
      {rows.length === 0 ? <p className="muted">No students found.</p> : (
        <div className="tablewrap"><table><thead><tr><th>Name</th><th>Email</th><th>Enrollments</th><th>Joined</th></tr></thead><tbody>
          {rows.map((u) => <tr key={u.id}><td>{u.name}</td><td>{u.email}</td><td>{u._count.enrollments}</td><td>{u.createdAt.toLocaleDateString("en-GB")}</td></tr>)}
        </tbody></table></div>)}
    </>
  );
}
