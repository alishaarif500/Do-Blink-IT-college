import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireApi } from "@/lib/auth";
import { check, statusSchema } from "@/lib/validation";

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  if (!(await requireApi("ADMIN"))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { data, errors } = check(statusSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  const app = await db.application.findUnique({ where: { id: params.id } });
  if (!app) return NextResponse.json({ errors: { form: "Application not found" } }, { status: 404 });
  await db.application.update({ where: { id: app.id }, data: { status: data.status } });
  if (data.status === "APPROVED") {
    // Enroll the student when an account with the same email exists.
    const user = await db.user.findUnique({ where: { email: app.email } });
    if (user) await db.enrollment.upsert({
      where: { userId_courseId: { userId: user.id, courseId: app.courseId } },
      update: {}, create: { userId: user.id, courseId: app.courseId }
    });
  }
  return NextResponse.json({ ok: true });
}
