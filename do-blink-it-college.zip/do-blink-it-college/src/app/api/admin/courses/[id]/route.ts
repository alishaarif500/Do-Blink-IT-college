import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { requireApi } from "@/lib/auth";
import { check, courseSchema, publishSchema } from "@/lib/validation";

type Ctx = { params: { id: string } };
const forbidden = () => NextResponse.json({ error: "Forbidden" }, { status: 403 });
const notFound = () => NextResponse.json({ errors: { form: "Course not found" } }, { status: 404 });

export async function PUT(req: Request, { params }: Ctx) {
  if (!(await requireApi("ADMIN"))) return forbidden();
  const { data, errors } = check(courseSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  const { modules, ...course } = data;
  try {
    await db.$transaction([
      db.courseModule.deleteMany({ where: { courseId: params.id } }),
      db.course.update({ where: { id: params.id }, data: { ...course, modules: { create: modules.map((title: string, position: number) => ({ title, position })) } } })
    ]);
  } catch { return notFound(); }
  return NextResponse.json({ ok: true });
}

export async function PATCH(req: Request, { params }: Ctx) {
  if (!(await requireApi("ADMIN"))) return forbidden();
  const { data, errors } = check(publishSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  try { await db.course.update({ where: { id: params.id }, data }); } catch { return notFound(); }
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: Ctx) {
  if (!(await requireApi("ADMIN"))) return forbidden();
  try {
    await db.course.delete({ where: { id: params.id } });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2003")
      return NextResponse.json({ errors: { form: "This course has applications. Unpublish it instead." } }, { status: 409 });
    return notFound();
  }
  return NextResponse.json({ ok: true });
}
