import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireApi } from "@/lib/auth";
import { check, courseSchema } from "@/lib/validation";

export async function POST(req: Request) {
  if (!(await requireApi("ADMIN"))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { data, errors } = check(courseSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  const base = data.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "course";
  let slug = base;
  for (let i = 2; await db.course.findUnique({ where: { slug } }); i++) slug = `${base}-${i}`;
  const { modules, ...course } = data;
  await db.course.create({ data: { ...course, slug, modules: { create: modules.map((title: string, position: number) => ({ title, position })) } } });
  return NextResponse.json({ ok: true });
}
