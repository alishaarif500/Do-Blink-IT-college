import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireApi } from "@/lib/auth";
import { check, readSchema } from "@/lib/validation";

type Ctx = { params: { id: string } };
const missing = () => NextResponse.json({ errors: { form: "Message not found" } }, { status: 404 });

export async function PATCH(req: Request, { params }: Ctx) {
  if (!(await requireApi("ADMIN"))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const { data, errors } = check(readSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  try { await db.contactMessage.update({ where: { id: params.id }, data }); } catch { return missing(); }
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: Request, { params }: Ctx) {
  if (!(await requireApi("ADMIN"))) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  try { await db.contactMessage.delete({ where: { id: params.id } }); } catch { return missing(); }
  return NextResponse.json({ ok: true });
}
