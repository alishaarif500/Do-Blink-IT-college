import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { applicationSchema, check } from "@/lib/validation";
import { limited } from "@/lib/rate";

export async function POST(req: Request) {
  if (limited(req, "apply", 5)) return NextResponse.json({ errors: { form: "Too many submissions. Try again in a minute." } }, { status: 429 });
  const { data, errors } = check(applicationSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  const course = await db.course.findFirst({ where: { id: data.courseId, published: true }, select: { id: true } });
  if (!course) return NextResponse.json({ errors: { courseId: "Choose an available course" } }, { status: 400 });
  const session = await getSession();
  try {
    await db.application.create({ data: { ...data, message: data.message || null, userId: session?.sub } });
  } catch (e) {
    if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002")
      return NextResponse.json({ errors: { form: "You have already applied for this course with this email." } }, { status: 409 });
    throw e;
  }
  return NextResponse.json({ ok: true });
}
