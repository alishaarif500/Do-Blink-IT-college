import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createSession, verifyPassword } from "@/lib/auth";
import { check, loginSchema } from "@/lib/validation";
import { limited } from "@/lib/rate";

export async function POST(req: Request) {
  if (limited(req, "login", 8)) return NextResponse.json({ errors: { form: "Too many attempts. Try again in a minute." } }, { status: 429 });
  const { data, errors } = check(loginSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  const u = await db.user.findUnique({ where: { email: data.email } });
  const ok = u ? await verifyPassword(data.password, u.passwordHash) : false;
  if (!u || !ok) return NextResponse.json({ errors: { form: "Incorrect email or password" } }, { status: 401 });
  await createSession({ sub: u.id, role: u.role, name: u.name });
  return NextResponse.json({ ok: true, redirect: u.role === "ADMIN" ? "/admin" : "/dashboard" });
}
