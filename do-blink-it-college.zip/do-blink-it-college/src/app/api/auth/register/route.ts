import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createSession, hashPassword } from "@/lib/auth";
import { check, registerSchema } from "@/lib/validation";
import { limited } from "@/lib/rate";

export async function POST(req: Request) {
  if (limited(req, "register", 5)) return NextResponse.json({ errors: { form: "Too many attempts. Try again in a minute." } }, { status: 429 });
  const { data, errors } = check(registerSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  if (await db.user.findUnique({ where: { email: data.email } }))
    return NextResponse.json({ errors: { email: "An account with this email already exists" } }, { status: 409 });
  const u = await db.user.create({ data: { name: data.name, email: data.email, passwordHash: await hashPassword(data.password) } });
  await createSession({ sub: u.id, role: u.role, name: u.name });
  return NextResponse.json({ ok: true, redirect: "/dashboard" });
}
