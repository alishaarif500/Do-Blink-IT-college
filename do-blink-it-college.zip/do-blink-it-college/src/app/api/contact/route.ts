import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { check, contactSchema } from "@/lib/validation";
import { limited } from "@/lib/rate";

export async function POST(req: Request) {
  if (limited(req, "contact", 5)) return NextResponse.json({ errors: { form: "Too many messages. Try again in a minute." } }, { status: 429 });
  const { data, errors } = check(contactSchema, await req.json().catch(() => null));
  if (errors) return NextResponse.json({ errors }, { status: 400 });
  await db.contactMessage.create({ data });
  return NextResponse.json({ ok: true });
}
