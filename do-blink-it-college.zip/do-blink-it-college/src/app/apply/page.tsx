import ApiForm from "@/components/ApiForm";
import { db } from "@/lib/db";

export const metadata = { title: "Admissions" };

export default async function Apply({ searchParams }: { searchParams: { course?: string } }) {
  const courses = await db.course.findMany({ where: { published: true }, orderBy: { title: "asc" }, select: { id: true, slug: true, title: true } });
  const preset = courses.find((c) => c.slug === searchParams.course)?.id ?? "";
  return (
    <div className="wrap section split">
      <div><h1>Admissions</h1><p>Complete the form to apply. The college reviews applications and contacts you about next steps.</p>
        {courses.length === 0 && <p className="err">No courses are open for applications yet.</p>}</div>
      <ApiForm url="/api/applications" submit="Submit application" success="Application received. Thank you! The college will contact you." fields={[
        { name: "fullName", label: "Full name", required: true, autoComplete: "name" },
        { name: "email", label: "Email address", type: "email", required: true, autoComplete: "email" },
        { name: "phone", label: "Phone number", type: "tel", required: true, autoComplete: "tel" },
        { name: "courseId", label: "Course", type: "select", required: true, defaultValue: preset, options: courses.map((c) => ({ value: c.id, label: c.title })) },
        { name: "education", label: "Education level", type: "select", required: true, options: ["Matric", "Intermediate", "Bachelor", "Master", "Other"].map((v) => ({ value: v, label: v })) },
        { name: "address", label: "Address", required: true, autoComplete: "street-address" },
        { name: "message", label: "Message (optional)", type: "textarea" }
      ]} />
    </div>
  );
}
