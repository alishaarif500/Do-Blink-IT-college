import ApiForm from "@/components/ApiForm";

export const metadata = { title: "Contact" };

export default function Contact() {
  return (
    <div className="wrap section split">
      <div>
        <h1>Contact us</h1><p>Questions about courses or admissions? Send a message.</p>
        <div className="card">
          <p><strong>Phone:</strong> [to be added]</p><p><strong>Email:</strong> [to be added]</p>
          <p><strong>Address:</strong> [to be added]</p><p><strong>WhatsApp:</strong> [link to be added]</p>
          <p style={{ margin: 0 }}><strong>Map:</strong> added once the address is provided.</p>
        </div>
      </div>
      <ApiForm url="/api/contact" submit="Send message" success="Message sent. Thank you! We will reply by email." fields={[
        { name: "name", label: "Your name", required: true, autoComplete: "name" },
        { name: "email", label: "Email address", type: "email", required: true, autoComplete: "email" },
        { name: "subject", label: "Subject", required: true },
        { name: "message", label: "Message", type: "textarea", required: true }
      ]} />
    </div>
  );
}
