import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";

export default async function CourseDetail({ params }: { params: { slug: string } }) {
  const c = await db.course.findFirst({ where: { slug: params.slug, published: true }, include: { modules: { orderBy: { position: "asc" } } } });
  if (!c) notFound();
  return (
    <div className="wrap section">
      <Link href="/courses">&larr; All courses</Link>
      <h1>{c.title}</h1><p>{c.description}</p>
      <p><span className="tag">{c.level}</span><span className="tag">{c.duration}</span><span className="tag">{c.fee == null ? "Fee to be confirmed" : `Fee: ${c.fee}`}</span></p>
      <div className="split">
        <div>
          <h2>Learning outcomes</h2><ul>{c.outcomes.map((o) => <li key={o}>{o}</li>)}</ul>
          <h2>Requirements</h2><p>{c.requirements || "None listed."}</p>
        </div>
        <div>
          <h2>Curriculum</h2><ol>{c.modules.map((m) => <li key={m.id}>{m.title}</li>)}</ol>
          <Link className="btn" href={`/apply?course=${c.slug}`}>Apply for this course</Link>
        </div>
      </div>
    </div>
  );
}
