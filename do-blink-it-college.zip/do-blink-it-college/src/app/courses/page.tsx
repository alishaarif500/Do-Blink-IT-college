import Link from "next/link";
import { db } from "@/lib/db";

export const metadata = { title: "Courses" };

export default async function Courses({ searchParams }: { searchParams: { q?: string; category?: string } }) {
  const q = searchParams.q?.trim();
  const category = searchParams.category || undefined;
  const [courses, cats] = await Promise.all([
    db.course.findMany({
      where: { published: true, category, ...(q ? { OR: [{ title: { contains: q, mode: "insensitive" } }, { description: { contains: q, mode: "insensitive" } }] } : {}) },
      orderBy: { title: "asc" }
    }),
    db.course.findMany({ where: { published: true }, select: { category: true }, distinct: ["category"], orderBy: { category: "asc" } })
  ]);
  return (
    <div className="wrap section">
      <h1>Courses</h1>
      <form className="filters" role="search">
        <input name="q" defaultValue={q} placeholder="Search courses" aria-label="Search courses" />
        <select name="category" defaultValue={category ?? ""} aria-label="Category">
          <option value="">All categories</option>
          {cats.map((c) => <option key={c.category}>{c.category}</option>)}
        </select>
        <button className="btn" type="submit">Filter</button>
      </form>
      {courses.length === 0 ? <p className="muted">No courses match your search.</p> : (
        <div className="grid">{courses.map((c) => (
          <article className="card" key={c.id}>
            <span className="tag">{c.category}</span><h3>{c.title}</h3><p className="muted">{c.description}</p>
            <p><span className="tag">{c.level}</span><span className="tag">{c.duration}</span><span className="tag">{c.fee == null ? "Fee to be confirmed" : `Fee: ${c.fee}`}</span></p>
            <div className="acts"><Link className="btn ghost" href={`/courses/${c.slug}`}>View details</Link><Link className="btn" href={`/apply?course=${c.slug}`}>Enroll</Link></div>
          </article>))}</div>)}
    </div>
  );
}
