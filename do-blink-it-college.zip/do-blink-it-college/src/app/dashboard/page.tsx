import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { requirePage } from "@/lib/auth";

export const metadata = { title: "My dashboard" };

export default async function Dashboard() {
  const s = await requirePage();
  const user = await db.user.findUnique({ where: { id: s.sub } });
  if (!user) redirect("/login");
  const [apps, enrollments] = await Promise.all([
    db.application.findMany({ where: { OR: [{ userId: user.id }, { email: user.email }] }, orderBy: { createdAt: "desc" }, include: { course: { select: { title: true, slug: true } } } }),
    db.enrollment.findMany({ where: { userId: user.id }, include: { course: { select: { title: true, slug: true, duration: true } } } })
  ]);
  return (
    <div className="wrap section">
      <h1>Welcome, {user.name}</h1>
      <div className="grid">
        <div className="card"><h3>Profile</h3><p>{user.name}<br />{user.email}</p><p className="muted">Member since {user.createdAt.toLocaleDateString("en-GB")}</p></div>
        <div className="card"><h3>Enrolled courses</h3>
          {enrollments.length === 0 ? <p className="muted">No enrollments yet. They appear here after an application is approved.</p>
            : <ul>{enrollments.map((e) => <li key={e.id}><Link href={`/courses/${e.course.slug}`}>{e.course.title}</Link> ({e.course.duration})</li>)}</ul>}
        </div>
      </div>
      <h2 style={{ marginTop: "2rem" }}>My applications</h2>
      {apps.length === 0 ? <p className="muted">You have not applied yet. <Link href="/apply">Apply for a course</Link></p> : (
        <div className="tablewrap"><table><thead><tr><th>Course</th><th>Status</th><th>Submitted</th></tr></thead><tbody>
          {apps.map((a) => <tr key={a.id}><td>{a.course.title}</td><td><span className={`badge ${a.status}`}>{a.status}</span></td><td>{a.createdAt.toLocaleDateString("en-GB")}</td></tr>)}
        </tbody></table></div>)}
    </div>
  );
}
