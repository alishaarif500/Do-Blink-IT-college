import type { Metadata } from "next";
import Link from "next/link";
import { Sora, DM_Sans } from "next/font/google";
import "./globals.css";
import { getSession } from "@/lib/auth";
import LogoutButton from "@/components/LogoutButton";

const head = Sora({ subsets: ["latin"], weight: ["500", "700"], variable: "--font-head" });
const body = DM_Sans({ subsets: ["latin"], weight: ["400", "500", "700"], variable: "--font-body" });

export const metadata: Metadata = {
  title: { default: "Do Blink IT College", template: "%s | Do Blink IT College" },
  description: "Practical IT courses, admissions and student support at Do Blink IT College."
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  return (
    <html lang="en" className={`${head.variable} ${body.variable}`}>
      <body>
        <header className="site">
          <div className="wrap bar">
            <Link className="logo" href="/"><i />Do Blink IT College</Link>
            <nav className="main" aria-label="Main">
              <Link href="/">Home</Link><Link href="/courses">Courses</Link><Link href="/contact">Contact</Link>
              <Link href="/apply">Apply</Link>
              {session ? (<>
                <Link href={session.role === "ADMIN" ? "/admin" : "/dashboard"}>{session.role === "ADMIN" ? "Admin" : "My dashboard"}</Link>
                <LogoutButton />
              </>) : (<><Link href="/login">Log in</Link><Link href="/register">Sign up</Link></>)}
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer className="site">
          <div className="wrap">
            <p><strong>Do Blink IT College</strong><br />[Phone: to be added] &middot; [Email: to be added] &middot; [Address: to be added]</p>
            <p>Social links will be added when the college provides them.</p>
            <p>&copy; {new Date().getFullYear()} Do Blink IT College</p>
          </div>
        </footer>
      </body>
    </html>
  );
}
