import Link from "next/link";
import ApiForm from "@/components/ApiForm";

export const metadata = { title: "Log in" };

export default function Login() {
  return (
    <div className="wrap section"><h1>Log in</h1>
      <ApiForm url="/api/auth/login" submit="Log in" fields={[
        { name: "email", label: "Email address", type: "email", required: true, autoComplete: "email" },
        { name: "password", label: "Password", type: "password", required: true, autoComplete: "current-password" }
      ]} />
      <p style={{ marginTop: "1rem" }}>New here? <Link href="/register">Create a student account</Link></p>
    </div>
  );
}
