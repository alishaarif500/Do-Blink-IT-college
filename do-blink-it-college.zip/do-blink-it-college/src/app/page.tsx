import Link from "next/link";
import { db } from "@/lib/db";

const faqs = [
  ["How do I apply?", "Open the Apply page, complete the form and submit it. The college reviews each application."],
  ["Do I need experience?", "Beginner courses need none. Each course page lists its requirements."],
  ["What are the fees?", "Fees are shown on each course and are set by the college."]
];

export default async function Home() {
  const courses = await db.course.findMany({ where: { published: true }, orderBy: { createdAt: "desc" }, take: 3 });
  return (
    <>
      <section className="hero"><div className="wrap">
        <h1>Learn IT skills by doing them</h1>
        <p>Do Blink IT College teaches technology through hands-on practice, so every lesson ends with something you built yourself.</p>
        <div className="acts"><Link className="btn" href="/apply">Apply for admission</Link><Link className="btn ghost" href="/courses">Browse courses</Link></div>
      </div></section>
      <section className="section"><div className="wrap">
        <h2>Why choose our college</h2>
        <div className="grid">
          {[["Practical training", "Lessons built around exercises and projects."], ["Clear learning paths", "Every course lists its outline and outcomes."], ["Simple admissions", "Apply online and track your status."]].map(([t, p]) => (
            <div className="card" key={t}><h3>{t}</h3><p className="muted">{p}</p></div>))}
        </div>
        <p className="muted" style={{ marginTop: "1rem" }}>[Placeholder text. Replace with the college’s own introduction.]</p>
      </div></section>
      <section className="section alt"><div className="wrap">
        <h2>Featured courses</h2>
        {courses.length === 0 ? <p className="muted">Courses will appear here once an admin publishes them.</p> : (
          <div className="grid">{courses.map((c) => (
            <article className="card" key={c.id}><span className="tag">{c.category}</span><h3>{c.title}</h3><p className="muted">{c.description}</p>
              <Link className="btn ghost" href={`/courses/${c.slug}`}>View details</Link></article>))}</div>)}
      </div></section>
      <section className="section"><div className="wrap">
        <h2>Frequently asked questions</h2>
        {faqs.map(([q, a]) => <details key={q}><summary>{q}</summary><p className="muted">{a}</p></details>)}
        <div className="acts"><Link className="btn" href="/apply">Apply now</Link><Link className="btn ghost" href="/contact">Ask a question</Link></div>
      </div></section>
    </>
  );
}
