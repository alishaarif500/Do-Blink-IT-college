import Link from "next/link";
import ApiForm from "@/components/ApiForm";

export const metadata = { title: "Sign up" };

export default function Register() {
  return (
    <div className="wrap section"><h1>Create a student account</h1>
      <ApiForm url="/api/auth/register" submit="Create account" fields={[
        { name: "name", label: "Full name", required: true, autoComplete: "name" },
        { name: "email", label: "Email address", type: "email", required: true, autoComplete: "email" },
        { name: "password", label: "Password (8+ characters)", type: "password", required: true, autoComplete: "new-password" }
      ]} />
      <p style={{ marginTop: "1rem" }}>Already registered? <Link href="/login">Log in</Link></p>
    </div>
  );
}
