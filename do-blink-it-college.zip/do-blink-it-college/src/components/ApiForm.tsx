"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export type Field = {
  name: string; label: string;
  type?: "text" | "email" | "tel" | "password" | "textarea" | "select" | "checkbox" | "number";
  options?: { value: string; label: string }[];
  required?: boolean; defaultValue?: string | boolean; autoComplete?: string;
};

type Props = {
  url: string; method?: "POST" | "PUT"; fields: Field[]; submit: string;
  success?: string; resetOnSuccess?: boolean;
};

export default function ApiForm({ url, method = "POST", fields, submit, success, resetOnSuccess = true }: Props) {
  const router = useRouter();
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (busy) return;
    const form = e.currentTarget;
    setBusy(true); setErrors({}); setDone("");
    const fd = new FormData(form);
    const body: Record<string, unknown> = {};
    for (const f of fields) body[f.name] = f.type === "checkbox" ? fd.get(f.name) === "on" : String(fd.get(f.name) ?? "");
    try {
      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const j = await res.json().catch(() => ({}));
      if (!res.ok) setErrors(j.errors ?? { form: "Something went wrong. Please try again." });
      else if (j.redirect) { router.push(j.redirect); router.refresh(); return; }
      else { setDone(success ?? "Saved."); if (resetOnSuccess) form.reset(); router.refresh(); }
    } catch {
      setErrors({ form: "Network error. Check your connection and try again." });
    }
    setBusy(false);
  }

  return (
    <form onSubmit={onSubmit} className="form">
      {fields.map((f) => {
        const err = errors[f.name];
        const common = { id: f.name, name: f.name, required: f.required, "aria-invalid": err ? true : undefined, "aria-describedby": err ? `${f.name}-err` : undefined, autoComplete: f.autoComplete };
        if (f.type === "checkbox") return (
          <label key={f.name} className="check"><input type="checkbox" id={f.name} name={f.name} defaultChecked={Boolean(f.defaultValue)} /> {f.label}</label>
        );
        return (
          <div key={f.name}>
            <label htmlFor={f.name}>{f.label}</label>
            {f.type === "textarea" ? <textarea {...common} rows={4} defaultValue={String(f.defaultValue ?? "")} />
              : f.type === "select" ? (
                <select {...common} defaultValue={String(f.defaultValue ?? "")}>
                  <option value="">Select...</option>
                  {f.options?.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
              ) : <input {...common} type={f.type ?? "text"} defaultValue={String(f.defaultValue ?? "")} min={f.type === "number" ? 0 : undefined} />}
            {err && <p className="err" id={`${f.name}-err`}>{err}</p>}
          </div>
        );
      })}
      {errors.form && <p className="err" role="alert">{errors.form}</p>}
      {done && <p className="ok" role="status">{done}</p>}
      <button className="btn" type="submit" disabled={busy}>{busy ? "Please wait..." : submit}</button>
    </form>
  );
}
