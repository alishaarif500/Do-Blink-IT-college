"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type Props = { url: string; method?: "PATCH" | "DELETE"; body?: unknown; label: string; confirmText?: string; danger?: boolean };

export default function RowAction({ url, method = "PATCH", body, label, confirmText, danger }: Props) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function go() {
    if (confirmText && !window.confirm(confirmText)) return;
    setBusy(true);
    try {
      const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        window.alert(j.errors?.form ?? "Action failed. Please try again.");
      }
    } catch { window.alert("Network error. Please try again."); }
    setBusy(false);
    router.refresh();
  }
  return <button type="button" className={danger ? "btn small danger" : "btn small ghost"} onClick={go} disabled={busy}>{busy ? "Working..." : label}</button>;
}
