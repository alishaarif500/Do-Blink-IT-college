import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import bcrypt from "bcryptjs";

export type Role = "STUDENT" | "ADMIN";
export type Session = { sub: string; role: Role; name: string };

const key = () => {
  if (!process.env.AUTH_SECRET) throw new Error("AUTH_SECRET is not set");
  return new TextEncoder().encode(process.env.AUTH_SECRET);
};

export const hashPassword = (p: string) => bcrypt.hash(p, 12);
export const verifyPassword = (p: string, h: string) => bcrypt.compare(p, h);

export async function createSession(s: Session) {
  const token = await new SignJWT({ role: s.role, name: s.name })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(s.sub)
    .setExpirationTime("7d")
    .sign(key());
  cookies().set("session", token, {
    httpOnly: true, sameSite: "lax", path: "/",
    secure: process.env.NODE_ENV === "production", maxAge: 60 * 60 * 24 * 7
  });
}

export async function getSession(): Promise<Session | null> {
  const token = cookies().get("session")?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, key());
    return { sub: String(payload.sub), role: payload.role as Role, name: String(payload.name) };
  } catch {
    return null;
  }
}

/** For server components: redirects when not allowed. */
export async function requirePage(role?: Role) {
  const s = await getSession();
  if (!s) redirect("/login");
  if (role && s.role !== role) redirect("/dashboard");
  return s;
}

/** For API routes: returns the session, or null when not allowed. */
export async function requireApi(role: Role) {
  const s = await getSession();
  return s && s.role === role ? s : null;
}
