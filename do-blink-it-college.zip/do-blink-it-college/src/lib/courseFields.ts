import type { Field } from "@/components/ApiForm";

export const courseFields: Field[] = [
  { name: "title", label: "Title", required: true },
  { name: "category", label: "Category", required: true },
  { name: "level", label: "Level", type: "select", required: true, options: ["Beginner", "Intermediate", "Advanced"].map((v) => ({ value: v, label: v })) },
  { name: "duration", label: "Duration (for example, 8 weeks)", required: true },
  { name: "fee", label: "Fee (whole number, leave empty if not set)", type: "number" },
  { name: "description", label: "Description", type: "textarea", required: true },
  { name: "requirements", label: "Requirements", type: "textarea" },
  { name: "outcomes", label: "Learning outcomes (one per line)", type: "textarea" },
  { name: "modules", label: "Curriculum modules (one per line)", type: "textarea" },
  { name: "published", label: "Published (visible on the website)", type: "checkbox" }
];
