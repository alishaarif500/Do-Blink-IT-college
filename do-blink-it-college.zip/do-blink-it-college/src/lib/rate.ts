// Simple in-memory limiter. Fine for one server; use Redis/Upstash when running several instances.
const hits = new Map<string, { n: number; t: number }>();

export function limited(req: Request, bucket: string, max = 10, windowMs = 60_000) {
  const ip = (req.headers.get("x-forwarded-for") ?? "local").split(",")[0].trim();
  const k = `${bucket}:${ip}`;
  const now = Date.now();
  const h = hits.get(k);
  if (!h || now - h.t > windowMs) { hits.set(k, { n: 1, t: now }); return false; }
  h.n += 1;
  return h.n > max;
}
