import { z } from "zod";

const email = z.string().trim().toLowerCase().email("Enter a valid email address").max(254);
const phone = z.string().trim().regex(/^[+\d][\d\s-]{6,19}$/, "Enter a valid phone number");
const lines = z.string().transform((s) => s.split("\n").map((x) => x.trim()).filter(Boolean));

export const registerSchema = z.object({
  name: z.string().trim().min(2, "Enter your name").max(100),
  email,
  password: z.string().min(8, "Use at least 8 characters").max(100)
});
export const loginSchema = z.object({ email, password: z.string().min(1, "Enter your password").max(100) });

export const applicationSchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name").max(100),
  email,
  phone,
  courseId: z.string().min(1, "Choose a course"),
  education: z.enum(["Matric", "Intermediate", "Bachelor", "Master", "Other"], { errorMap: () => ({ message: "Choose your education level" }) }),
  address: z.string().trim().min(5, "Enter your address").max(300),
  message: z.string().trim().max(1000).optional()
});

export const contactSchema = z.object({
  name: z.string().trim().min(2, "Enter your name").max(100),
  email,
  subject: z.string().trim().min(3, "Enter a subject").max(150),
  message: z.string().trim().min(10, "Write at least 10 characters").max(2000)
});

export const courseSchema = z.object({
  title: z.string().trim().min(3, "Enter a title").max(120),
  category: z.string().trim().min(2, "Enter a category").max(50),
  level: z.enum(["Beginner", "Intermediate", "Advanced"], { errorMap: () => ({ message: "Choose a level" }) }),
  duration: z.string().trim().min(1, "Enter a duration").max(50),
  fee: z.preprocess((v) => (v === "" || v == null ? null : Number(v)), z.number({ invalid_type_error: "Enter a number" }).int().min(0).nullable()),
  description: z.string().trim().min(10, "Write at least 10 characters").max(2000),
  requirements: z.string().trim().max(500),
  outcomes: lines,
  modules: lines,
  published: z.boolean()
});

export const statusSchema = z.object({ status: z.enum(["PENDING", "APPROVED", "REJECTED"]) });
export const publishSchema = z.object({ published: z.boolean() });
export const readSchema = z.object({ read: z.boolean() });

export function check<S extends z.ZodTypeAny>(
  schema: S, input: unknown
): { data: z.infer<S>; errors: null } | { data: null; errors: Record<string, string> } {
  const r = schema.safeParse(input);
  if (r.success) return { data: r.data, errors: null };
  const errors: Record<string, string> = {};
  for (const i of r.error.issues) errors[String(i.path[0] ?? "form")] ??= i.message;
  return { data: null, errors };
}
