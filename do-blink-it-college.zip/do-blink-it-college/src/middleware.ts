import { NextResponse, type NextRequest } from "next/server";
import { jwtVerify } from "jose";

export async function middleware(req: NextRequest) {
  const token = req.cookies.get("session")?.value;
  let role: string | null = null;
  if (token && process.env.AUTH_SECRET) {
    try {
      const { payload } = await jwtVerify(token, new TextEncoder().encode(process.env.AUTH_SECRET));
      role = String(payload.role);
    } catch { /* invalid or expired */ }
  }
  const path = req.nextUrl.pathname;
  const api = path.startsWith("/api/");
  if (!role) return api ? NextResponse.json({ error: "Unauthorized" }, { status: 401 }) : NextResponse.redirect(new URL("/login", req.url));
  const adminOnly = path.startsWith("/admin") || path.startsWith("/api/admin");
  if (adminOnly && role !== "ADMIN") return api ? NextResponse.json({ error: "Forbidden" }, { status: 403 }) : NextResponse.redirect(new URL("/dashboard", req.url));
  return NextResponse.next();
}

// Middleware is a first gate only. Every API route and admin page also checks the role on the server.
export const config = { matcher: ["/admin/:path*", "/dashboard/:path*", "/api/admin/:path*"] };
